#!/bin/bash
echo "Running...\n"
node index.js
