#!/bin/bash
echo "Running Local Client ...\n"
cd client
npm start
